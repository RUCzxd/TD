#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>
class Enemy
{
     Enemy();
};
#endif // ENEMY_H
